var hashv = document.hashv;
var k = '';
var esim = 0;
var urish = false;
var hishox = 0;

function qar() {
    var ard = mutq.value * mutq.value;
    mutq.value = ard;
}

function armat() {
    var x = Math.sqrt(mutq.value);
    mutq.value = x;
}

function xor() {
    var ard = mutq.value * mutq.value * mutq.value;
    mutq.value = ard;
}

function f(n) {
    if (urish) {
        hashv.mutq.value = n;
        urish = false;
    }
    else {
        if (hashv.mutq.value == '0')
            hashv.mutq.value = n;
        else
            hashv.mutq.value += n;
    }
}

function o(m) {
    var mutq = hashv.mutq.value;
    if (urish && k != '=') {
        hashv.mutq.value = esim;
    }
    else {
        urish = true;
        switch (k) {
            case '+':
                esim += parseFloat(mutq);
                break;
            case '-':
                esim -= parseFloat(mutq);
                break;
            case '*':
                esim *= parseFloat(mutq);
                break;
            case '/':
                esim /= parseFloat(mutq);
                break;
            default:
                esim = parseFloat(mutq);
        }
        hashv.mutq.value = esim;
        k = m;
    }
}

function jnjum() {
    esim = 0;
    k = '';
    mutq.value = "0";
    urish = true;
}

function memoryMs() {
    hishox = parseFloat(mutq.value);
}

function memoryM() {
    mutq.value = hishox + parseFloat(mutq.value);
}

function memory_M() {
    mutq.value = parseFloat(mutq.value) - hishox;
}

function memoryMc() {
   hishox = 0;
}

function nshan() {
    mutq.value = parseFloat(mutq.value) * (-1);
}
/* privet*/
//  poka  //
